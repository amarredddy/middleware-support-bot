# Deploying middleware-support-bot to OpenShift

You're on a machine that already has the `oc` CLI installed and logged into
the target cluster. This archive contains everything needed - no separate
Dockerfile or config to write, they're already here.

## 0. Rename one file first (required)

Gmail strips `.js` files even inside archives, so `static/app.js` was
renamed to `static/app.js.txt` before sending. Rename it back before doing
anything else, or the chatbot's UI will not load (404 on app.js):

```bash
# from the folder you extracted this archive into
mv static/app.js.txt static/app.js        # Windows: ren static\app.js.txt app.js
```

```
middleware-support-bot/
├── app/                  FastAPI app (main.py, config.py, models.py)
├── static/               index.html, styles.css, app.js (the chatbot UI)
├── config/support.yaml   product links, GitHub repos, ServiceNow/xMatters URLs
├── Dockerfile            builds the container image
├── deploy.yaml           Namespace, ConfigMap, BuildConfig, Deployment, Service, Route, HPA
├── requirements.txt
└── README.md             full reference docs (this file is the short version)
```

## 1. Confirm you're logged in

```bash
oc whoami
oc project   # shows current project/namespace, if any
```

If not logged in:
```bash
oc login https://api.YOUR_CLUSTER:6443
```

## 2. Put your real links into deploy.yaml before applying

Open `deploy.yaml` and find the `ConfigMap` block (`data: | support.yaml:`,
around lines 24-104). Replace its contents with your real values - same
format as `config/support.yaml`, just copy that file's content in with the
same indentation. Replace every `YOUR_*` placeholder:

| Placeholder | Replace with |
|---|---|
| `YOUR_WEBSPHERE_ADMIN_CONSOLE.example.com` | Your real WebSphere admin console URL |
| `YOUR_PCC_CATALOG.example.com` | Your product catalog / PCC URL |
| `wiki.YOUR_ORG.example.com/...` | Your internal wiki/runbook links |
| `YOUR_MONITORING_TOOL.example.com` | Your monitoring dashboards |
| `YOUR_INSTANCE.service-now.com` | Your ServiceNow instance |
| `YOUR_ORG.xmatters.com` | Your xMatters trigger URL |
| `middleware-ops@YOUR_ORG.example.com` | Your Middleware Operations DL |
| `YOUR_GITHUB_ORG` | The GitHub org that owns your five support repos |

(Optional) If you want a different namespace than `middleware-support`,
change `metadata.namespace` on **every** resource in `deploy.yaml` AND the
image path inside the `Deployment` (`image-registry.openshift-image-registry.svc:5000/<namespace>/middleware-support-bot:latest`).
Simplest is to leave the namespace as `middleware-support`.

## 3. Create everything

```bash
oc apply -f deploy.yaml
```

Creates the namespace, ConfigMap, ImageStream, BuildConfig, Deployment
(2 replicas), Service, Route (TLS edge), and HorizontalPodAutoscaler. No
container image exists yet - that's the next step.

## 4. Build the image from this source

Run from the folder you unzipped this into (the one containing `Dockerfile`):

```bash
oc -n middleware-support start-build middleware-support-bot --from-dir=. --follow
```

This uploads the current directory as a binary build and builds the image
using the `Dockerfile` here. `.dockerignore` already excludes dev-only
files (`.venv`, logs, etc.) from the upload.

## 5. Watch the rollout

```bash
oc -n middleware-support rollout status deployment/middleware-support-bot
```

## 6. Get the URL

```bash
oc -n middleware-support get route middleware-support-bot -o jsonpath='{.spec.host}{"\n"}'
```

Open that hostname in a browser - that's the chatbot.

## Updating later

**Just links (no rebuild):**
```bash
oc -n middleware-support edit configmap middleware-support-content
# edit the support.yaml block, save/exit
oc -n middleware-support rollout restart deployment/middleware-support-bot
```

**Code changes (rebuild):**
```bash
oc -n middleware-support start-build middleware-support-bot --from-dir=. --follow
```

See `README.md` for the full walkthrough, including Teams-tab embedding and
the phase 2/3 roadmap.
