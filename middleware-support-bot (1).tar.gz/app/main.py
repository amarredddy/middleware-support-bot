import os
from datetime import datetime, timezone
from urllib.parse import urlparse

from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

from .config import get_products, get_product, get_settings, load_config
from .models import IncidentRouteRequest, EscalationRequest, GithubUrlValidationRequest

app = FastAPI(title="Middleware Support Chatbot", version="1.0.0-phase1")

REQUIRED_ESCALATION_FIELDS = [
    "incident_number",
    "environment",
    "application",
    "server_names",
    "impact",
    "errors",
    "start_time",
    "ops_debugging",
    "findings",
    "recent_changes",
    "approving_engineer",
    "product_id",
]


@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.get("/api/config")
def config():
    settings = get_settings()
    products = [
        {
            "id": p["id"],
            "name": p["name"],
            "description": p.get("description", ""),
            "resources": p.get("resources", []),
            "github": p.get("github", {}),
        }
        for p in get_products()
    ]
    return {"settings": settings, "products": products}


@app.post("/api/config/reload")
def reload_config():
    """Admin-only in practice (put this behind your OpenShift Route/network
    policy or remove it) - re-reads support.yaml without restarting the pod."""
    load_config(force_reload=True)
    return {"status": "reloaded"}


@app.get("/api/products/{product_id}")
def product_detail(product_id: str):
    product = get_product(product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Unknown product")
    return product


@app.post("/api/incident-route")
def incident_route(req: IncidentRouteRequest):
    settings = get_settings()
    env = req.environment

    if env == "critical_production":
        return {
            "action": "page_operations",
            "message": "This is a critical production issue. Page Middleware Operations now.",
            "xmatters_url": settings.get("xmatters_url"),
            "servicenow_url": settings.get("servicenow_url"),
            "next_step": "open_production_incident_and_page",
        }
    elif env == "noncritical_production":
        return {
            "action": "open_incident",
            "message": "Open a normal-priority production incident, then loop in Middleware Operations.",
            "servicenow_url": settings.get("servicenow_url"),
            "middleware_ops_dl": settings.get("middleware_ops_dl"),
            "next_step": "open_production_incident",
        }
    elif env == "nonproduction":
        return {
            "action": "open_incident",
            "message": "Open a nonproduction incident and loop in Middleware Operations.",
            "servicenow_url": settings.get("servicenow_url"),
            "middleware_ops_dl": settings.get("middleware_ops_dl"),
            "next_step": "open_nonproduction_incident",
        }
    else:
        raise HTTPException(status_code=400, detail="environment must be one of: "
                             "critical_production, noncritical_production, nonproduction")


def _generate_report_markdown(req: EscalationRequest, product: dict) -> str:
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    return f"""## Application Runtime Escalation Report

**Generated:** {ts}
**Product:** {product['name']}
**Incident Number:** {req.incident_number}
**Environment / Application:** {req.environment} / {req.application}
**Server / JVM / Cluster / Host:** {req.server_names}

### Impact
{req.impact}

### Errors
{req.errors}

### Start Time
{req.start_time}

### Middleware Operations Debugging Performed
{req.ops_debugging}

### Findings and Recent Changes
{req.findings}

**Recent changes:** {req.recent_changes}

### Approving Middleware Engineer
{req.approving_engineer}

---
*Paste this report into a new GitHub issue in the {product['name']} repository:*
{product['github']['issues_url']}
"""


@app.post("/api/escalation")
def create_escalation(req: EscalationRequest):
    product = get_product(req.product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Unknown product")

    missing = [f for f in REQUIRED_ESCALATION_FIELDS if not getattr(req, f, "").strip()]
    if missing:
        raise HTTPException(status_code=400, detail={"missing_fields": missing})

    report_md = _generate_report_markdown(req, product)
    return {
        "report_markdown": report_md,
        "github_issues_url": product["github"]["issues_url"],
        "product_name": product["name"],
    }


@app.post("/api/validate-github-issue-url")
def validate_github_issue_url(req: GithubUrlValidationRequest):
    product = get_product(req.product_id)
    if not product:
        raise HTTPException(status_code=404, detail="Unknown product")

    url = req.url.strip()
    parsed = urlparse(url)

    if parsed.scheme != "https":
        return {"valid": False, "reason": "URL must use https://"}

    expected_org = product["github"]["org"]
    expected_repo = product["github"]["repo"]
    expected_path_prefix = f"/{expected_org}/{expected_repo}"

    if parsed.netloc != "github.com" or not parsed.path.startswith(expected_path_prefix):
        return {
            "valid": False,
            "reason": f"Expected a URL under github.com{expected_path_prefix}",
            "expected_repository": f"https://github.com{expected_path_prefix}",
        }

    parts = [p for p in parsed.path.split("/") if p]
    # parts == [org, repo, "issues", "<number>"]
    if len(parts) < 4 or parts[2] != "issues" or not parts[3].isdigit():
        return {
            "valid": False,
            "reason": "URL must point to a specific issue, e.g. "
                      f".../{expected_repo}/issues/123",
        }

    return {"valid": True, "issue_number": int(parts[3])}


# --- Static frontend (served last so /api/* routes above take priority) ---
static_dir = os.path.join(os.path.dirname(__file__), "..", "static")
app.mount("/static", StaticFiles(directory=static_dir), name="static")


@app.get("/")
def index():
    return FileResponse(f"{static_dir}/index.html")
