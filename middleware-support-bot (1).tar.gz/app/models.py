from typing import Optional
from pydantic import BaseModel, Field


class IncidentRouteRequest(BaseModel):
    environment: str = Field(
        ..., description="critical_production | noncritical_production | nonproduction"
    )
    product_id: Optional[str] = None


class EscalationRequest(BaseModel):
    incident_number: str
    environment: str
    application: str
    server_names: str
    impact: str
    errors: str
    start_time: str
    ops_debugging: str
    findings: str
    recent_changes: str
    approving_engineer: str
    product_id: str


class GithubUrlValidationRequest(BaseModel):
    product_id: str
    url: str
