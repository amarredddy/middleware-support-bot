import os
import threading
import yaml

_DEFAULT_PATH = os.path.join(os.path.dirname(__file__), "..", "config", "support.yaml")
CONFIG_PATH = os.environ.get("CONFIG_PATH", _DEFAULT_PATH)

_lock = threading.Lock()
_cache = None


def load_config(force_reload: bool = False) -> dict:
    """Load support.yaml. Cached in memory; call with force_reload=True
    (or restart the pod, see README) to pick up ConfigMap edits."""
    global _cache
    with _lock:
        if _cache is None or force_reload:
            with open(CONFIG_PATH, "r") as f:
                _cache = yaml.safe_load(f)
        return _cache


def get_products() -> list:
    return load_config().get("products", [])


def get_product(product_id: str) -> dict | None:
    for p in get_products():
        if p["id"] == product_id:
            return p
    return None


def get_settings() -> dict:
    return load_config().get("settings", {})
